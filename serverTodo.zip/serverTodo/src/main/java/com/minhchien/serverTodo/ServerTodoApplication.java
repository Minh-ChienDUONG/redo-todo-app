package com.minhchien.serverTodo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ServerTodoApplication {

	public static void main(String[] args) {
		SpringApplication.run(ServerTodoApplication.class, args);
	}

}
